package de.suitepad.packagelist;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import de.suitepad.packagelist.models.Pkg;

public class MainActivity extends AppCompatActivity
{
    public static final String EXTRA_PACKAGE_DETAILS = "package_details";
    public static final String EXTRA_PACKAGE_NAME = "extra_package_name";
    public static final int PACKAGE_INSTALL = 1;
    public static final int PACKAGE_CHANGED = 2;
    public static final int PACKAGE_UNINSTALL = 3;

    private ListView listView;

    @Override
    protected void onCreate( Bundle savedInstanceState )
    {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );
        listView = ( ListView ) findViewById( R.id.package_list );

        int packageDetails = getIntent().getIntExtra( EXTRA_PACKAGE_DETAILS, 0 );
        if ( packageDetails > 0 )
        {
            String packageName = getIntent().getStringExtra( EXTRA_PACKAGE_NAME );
            switch ( packageDetails )
            {
                case PACKAGE_INSTALL:
                    onPackageInstalled( packageName );
                    break;
                case PACKAGE_CHANGED:
                    onPackageChanged( packageName );
                    break;
                case PACKAGE_UNINSTALL:
                    onPackageUninstalled( packageName );
                    break;
            }
        }
        else
        {
            populatePackages();
        }
    }

    public void onPackageUninstalled( String pkgName )
    {
        Toast.makeText( this, pkgName + " is uninstalled", Toast.LENGTH_SHORT ).show();
        populatePackages();
    }

    public void onPackageInstalled( String pkgName )
    {
        Toast.makeText( this, pkgName + " is installed", Toast.LENGTH_SHORT ).show();
        populatePackages();
    }

    public void onPackageChanged( String pkgName )
    {
        Toast.makeText( this, pkgName + " is changed", Toast.LENGTH_SHORT ).show();
        populatePackages();
    }

    public void populatePackages()
    {
        ArrayList<Pkg> pkgList = new ArrayList<>();
        PackageListAdapter packageListAdapter = new PackageListAdapter( this, pkgList );
        listView.setAdapter( packageListAdapter );
        pkgList.clear();
        PackageManager pm = getPackageManager();
        List<PackageInfo> packages = pm.getInstalledPackages( PackageManager.GET_META_DATA );

        for ( PackageInfo packageInfo : packages )
        {
            pkgList.add( new Pkg( packageInfo.packageName, packageInfo.packageName, packageInfo.versionName,
                    packageInfo.versionCode ) );
        }
    }

    class PackageListAdapter extends ArrayAdapter<Pkg>
    {

        public PackageListAdapter( Context context, List<Pkg> packages )
        {
            super( context, R.layout.list_item_package, packages );
        }

        @NonNull
        @Override
        public View getView( int position, @Nullable View convertView, @NonNull ViewGroup parent )
        {
            View v = convertView;
            final Pkg p = getItem( position );
            ViewHolder viewHolder;
            if ( v == null )
            {
                LayoutInflater vi;
                vi = LayoutInflater.from( getContext() );
                v = vi.inflate( R.layout.list_item_package, null );
                viewHolder = new ViewHolder();

                viewHolder.packageLable = ( TextView ) v.findViewById( R.id.pkg_label );
                viewHolder.packageName = ( TextView ) v.findViewById( R.id.pkg_name );
                viewHolder.packageVersion = ( TextView ) v.findViewById( R.id.pkg_version );
                viewHolder.packageUninstall = ( Button ) v.findViewById( R.id.pkg_uninstall );
                viewHolder.packageLaunch = ( Button ) v.findViewById( R.id.pkg_launch );
                viewHolder.packageIcon = ( ImageView ) v.findViewById( R.id.pkg_icon );

                v.setTag( viewHolder );
            }

            viewHolder = ( ViewHolder ) v.getTag();
            viewHolder.packageLable.setText( p.getLabel() );
            viewHolder.packageName.setText( p.getName() );
            viewHolder.packageVersion.setText( p.getVersionName() );

            viewHolder.packageUninstall.setOnClickListener( new View.OnClickListener()
            {
                @Override
                public void onClick( View v )
                {
                    Toast.makeText( getApplicationContext(), "Uninstalling package: " + p.getName(),
                            Toast.LENGTH_SHORT ).show();
                }
            } );

            viewHolder.packageLaunch.setOnClickListener( new View.OnClickListener()
            {
                @Override
                public void onClick( View v )
                {
                    Toast.makeText( getApplicationContext(), "Launching package: " + p.getName(),
                            Toast.LENGTH_SHORT ).show();
                }
            } );
            return v;
        }
    }

    static class ViewHolder
    {
        private TextView packageName;
        private TextView packageVersion;
        private TextView packageLable;
        private Button packageUninstall;
        private Button packageLaunch;
        private ImageView packageIcon;
    }

}
